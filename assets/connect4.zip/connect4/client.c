#include "game.h"

void format_table(char*inbuf, c4_t localTable){
    int i=HEIGHT,j=0,k;
    for (k=0;k<strlen(inbuf);k++){
        if (k%WIDTH==0){
            i--;
            j=0;
        }
        localTable[HEIGHT-i-1][j++]=inbuf[k];
    }
}

void socket_write(int sockfd, char* buffer){
    int n;
    n = write(sockfd,buffer,strlen(buffer));
    if (n < 0) 
         error("ERROR writing to socket");
}

int socket_read(int sockfd, char* buffer){
    int n;
    bzero(buffer,BUFSIZE);
    n = read(sockfd,buffer,BUFSIZE);
    if (n < 0) 
         error("ERROR reading from socket");
     if (strcmp(GAMEOVER,buffer)==0){ //if the game is over
        printf("%s\n", buffer);
        socket_write(sockfd, ACK); //acknowledge gameover
        socket_read(sockfd, buffer);//get game over type
        printf("%s\n", buffer);
        close(sockfd);
        exit(0);
     }
     if (strcmp(INVALIDMOVE, buffer)==0){
        printf("%s\n", buffer);
        return 1;
     }
     //printf("%s\n", buffer);
     return 0;
     
}

char* get_input(char* buffer){
    printf("enter column number: ");
    bzero(buffer,BUFSIZE);
    fgets(buffer,BUFSIZE-1,stdin);
    return buffer;
}


int main(int argc, char *argv[])
{
    int sockfd, portno;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    c4_t localTable;

    char buffer[BUFSIZE];
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");

    socket_read(sockfd, buffer);
    printf("%s\n", buffer ); //Welcome to Connect 4
    while(1){
        socket_write(sockfd,get_input(buffer));
        
        while(socket_read(sockfd, buffer)){//loop until user gives valid input
            socket_write(sockfd,get_input(buffer));
        }
        format_table(buffer, localTable); //display user's move
        print_config(localTable);
    }


    
    close(sockfd);
    return 0;
}


void error(char *msg)
{
    perror(msg);
    exit(0);
}

void
print_config(c4_t board) {
    int r, c, i, j;
    char a;
    /* lots of complicated detail in here, mostly this function
     * is an exercise in attending to detail and working out the
     * exact layout that is required.
     */
    printf("\n");
    /* print cells starting from the top, each cell is spread over
     * several rows
     */
    for (r=HEIGHT-1; r>=0; r--) {
        for (i=0; i<HGRID; i++) {
            printf("\t|");
            /* next two loops step across one row */
            for (c=0; c<WIDTH; c++) {
                for (j=0; j<WGRID; j++) {
                    if ((a=board[r][c])==RED){
                        printf(ANSI_RED "█" ANSI_RESET);                        
                    } else if (a==YELLOW){
                        printf(ANSI_YELLOW "▓" ANSI_RESET);
                    } else{
                        printf("%c",a);
                    }
                    
                }
                printf("|");
            }
            printf("\n");
        }
    }
    /* now print the bottom line */
    printf("\t+");
    for (c=0; c<WIDTH; c++) {
        for (j=0; j<WGRID; j++) {
            printf("-");
        }
        printf("+");
    }
    printf("\n");
    /* and the bottom legend */
    printf("\t ");
    for (c=0; c<WIDTH; c++) {
        for (j=0; j<(WGRID-1)/2; j++) {
            printf(" ");
        }
        printf("%1d ", c+1);
        for (j=0; j<WGRID-1-(WGRID-1)/2; j++) {
            printf(" ");
        }
    }
    printf("\n\n");
}