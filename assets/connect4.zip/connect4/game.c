/* Connect 4: a simple text based implementation */
#include "game.h"

void send_board(c4_t board,int gamesock){
	char buffer[BUFSIZE];
	int n=0,i,j;
	for (i=0;i<HEIGHT;i++){
        for (j=0;j<WIDTH;j++){
            buffer[n++]=board[i][j];
        }
    }
    buffer[n]='\0';    
	n = write(gamesock, buffer, strlen(buffer));
	if (n<strlen(buffer)){
		printf("didn't send full board\n");
		exit(1);
	}
}

void send_message(char* sendstring, int gamesock){	
    if (write(gamesock,sendstring,strlen(sendstring)) < strlen(sendstring)) 
         error("ERROR writing to socket");
}

void send_gameover(char* reason, int gamesock){
	/*sends gameover message, waits for acknowledgement,
	then sends gameover reason*/
	char buffer[BUFSIZE];
	bzero(buffer, BUFSIZE);
	send_message(GAMEOVER,gamesock);//send gameover
	read(gamesock,&buffer, 4);//wait for ACK
	if (strcmp(buffer,ACK)==0){ 
		send_message(reason,gamesock); //send game over reason
		pthread_exit(EXIT_SUCCESS);
		
	} else {
		pthread_exit(EXIT_SUCCESS);
	}
}

void
write_log(struct thread_data* indata, char* message){
	time_t mytime=time(NULL);
    struct tm *tmptime= localtime(&mytime);    
    char timebuf[BUFSIZE];
	strftime(timebuf, BUFSIZE, "%x %T", tmptime);
	pthread_mutex_lock(&lock); //critical region       
    fprintf(logfile, "%s\t %s\t socket: %d\t%s\n", timebuf, indata->ip, indata->sockfd, message); 
    pthread_mutex_unlock(&lock);
}

void*
run_game(void* tdata) {

	c4_t board;
	int move;	
    char buffer[BUFSIZE];
    char logmessage[BUFSIZE];
    bzero(buffer,BUFSIZE);
    struct thread_data *indata;
    struct thread_data srvdata;
   	indata = (struct thread_data *) tdata;
   	int gamesock = indata->sockfd;
   	strcpy(srvdata.ip,"0.0.0.0");
   	srvdata.sockfd=gamesock;

	srand(RSEED);
	init_empty(board);

	write_log(indata,"client connected");
	//print_config(board);

	/* main loop does two moves each iteration, one from the human
	 * playing, and then one from the computer program (or game server)
	 */
	send_message("Welcome to Connect 4",gamesock);
	while ((move = get_move(board, gamesock)) != EOF) {
		/* process the person's move */
		if (do_move(board, move, YELLOW)!=1) {
			printf("Panic\n");
			pthread_exit(EXIT_SUCCESS);
		}
		sprintf(logmessage,"Client's move = %d",move);
		write_log(indata, logmessage);
		//print_config(board);

		if (winner_found(board) == YELLOW) {
			/* rats, the person beat us! */
			write_log(indata, "game over, client wins");
			send_gameover("You win",gamesock);
		}
		/* was that the last possible move? */
		if (!move_possible(board)) {			
			write_log(indata, "game over, draw");
			send_gameover("A draw!",gamesock);
		}
		/* otherwise, look for a move from the computer */
		move = suggest_move(board, RED);
		//printf(" I play in column %d\n", move);
		if (do_move(board, move, RED)!=1) {
			printf("Panic\n");
			pthread_exit(EXIT_SUCCESS);
		}
		sprintf(logmessage,"Server's move = %d",move);
		write_log(&srvdata, logmessage);
		//print_config(board);		
		/* and did we win??? */
		if (winner_found(board) == RED) {
			/* yes!!! */
			write_log(indata, "game over, server wins");
			send_gameover("Computer Won",gamesock);				
		}		
		send_board(board,gamesock);
		/* otherwise, the game goes on */
	}
	printf("\n");
	return 0;
}

/* Initialise the playing array to empty cells */
void
init_empty(c4_t board) {
	int r, c;
	for (r=HEIGHT-1; r>=0; r--) {
		for (c=0; c<WIDTH; c++) {
			board[r][c] = EMPTY;
		}
	}
	//printf("Welcome to connect-4 \n\n");
}

/* Apply the specified move to the board
 */
int
do_move(c4_t board, int c, char colour) {
	int r=0;
	/* first, find the next empty slot in that column */
	while ((r<HEIGHT) && (board[r][c-1]!=EMPTY)) {
		r += 1;
	}
	if (r==HEIGHT) {
		/* no move is possible */
		return 0;
	}
	/* otherwise, do the assignment */
	board[r][c-1] = colour;
	return 1;
}

/* Remove the top token from the specified column c
 */
void
undo_move(c4_t board, int c) {
	int r=0;
	/* first, find the next empty slot in that column, but be
	 * careful not to run over the top of the array
	 */
	while ((r<HEIGHT) && board[r][c-1] != EMPTY) {
		r += 1;
	}
	/* then do the assignment, assuming that r>=1 */
	board[r-1][c-1] = EMPTY;
	return;
}

/* Check board to see if it is full or not */
int
move_possible(c4_t board) {
	int c;
	/* check that a move is possible */
	for (c=0; c<WIDTH; c++) {
		if (board[HEIGHT-1][c] == EMPTY) {
			/* this move is possible */
			return 1;
		}
	}
	/* if here and loop is finished, and no move possible */
	return 0;
}


/* Read the next column number, and check for legality 
 */
int
get_move(c4_t board, int gamesock) {
	char in;
	int c,n;
	/* check that a move is possible */
	if (!move_possible(board)) {
		return EOF;
	}
	/* one is, so ask for user input */
	//printf("Enter column number: ");
	if ((n = read(gamesock,&in,2))<1) {
		return EOF;
	}
	c=atoi(&in);

	/* and keep asking until a valid move is entered */
	while ((c<=0) || (c>WIDTH) || (board[HEIGHT-1][c-1]!=EMPTY)) {
		//printf("That move is not possible. ");
		//printf("Enter column number: ");
		send_message(INVALIDMOVE, gamesock);
		if ((n = read(gamesock,&in,2))<1) {
			return EOF;
		}
		c=atoi(&in);
	}
	/* now have a valid move */
	return c;
}

/* Print out the current configuration of the board 
 */
void
print_config(c4_t board) {
	int r, c, i, j;
	char a;
	/* lots of complicated detail in here, mostly this function
	 * is an exercise in attending to detail and working out the
	 * exact layout that is required.
	 */
	printf("\n");
	/* print cells starting from the top, each cell is spread over
	 * several rows
	 */
	for (r=HEIGHT-1; r>=0; r--) {
		for (i=0; i<HGRID; i++) {
			printf("\t|");
			/* next two loops step across one row */
			for (c=0; c<WIDTH; c++) {
				for (j=0; j<WGRID; j++) {
					if ((a=board[r][c])==RED){
						printf(ANSI_RED "█" ANSI_RESET);
					} else if (a==YELLOW){
						printf(ANSI_YELLOW "▓" ANSI_RESET);
					} else{
						printf("%c",a);
					}
					
				}
				printf("|");
			}
			printf("\n");
		}
	}
	 // for(i=HEIGHT-1;i>=0;i--){
	 // 	for (j=0;j<WIDTH;j++){
	 // 		printf("%c",board[i][j] );
	 // 	}
	 // 	printf("\n");
	 // }
	/* now print the bottom line */
	printf("\t+");
	for (c=0; c<WIDTH; c++) {
		for (j=0; j<WGRID; j++) {
			printf("-");
		}
		printf("+");
	}
	printf("\n");
	/* and the bottom legend */
	printf("\t ");
	for (c=0; c<WIDTH; c++) {
		for (j=0; j<(WGRID-1)/2; j++) {
			printf(" ");
		}
		printf("%1d ", c+1);
		for (j=0; j<WGRID-1-(WGRID-1)/2; j++) {
			printf(" ");
		}
	}
	printf("\n\n");
}

/* Is there a winning position on the current board?
 */
char
winner_found(c4_t board) {
	int r, c;
	/* check exhaustively from every position on the board
	 * to see if there is a winner starting at that position.
	 * could probably short-circuit some of the computatioin,
	 * but hey, the computer has plenty of time to do the tesing
	 */
	for (r=0; r<HEIGHT; r++) {
		for (c=0; c<WIDTH; c++) {
			if ((board[r][c]!=EMPTY) && rowformed(board,r,c)) {
				return board[r][c];
			}
		}
	}
	/* ok, went right through all positions and if we are still
	 * here then there isn't a solution to be found
	 */
	return EMPTY;
}


/* Is there a row in any direction starting at [r][c]?
 */
int
rowformed(c4_t board, int r, int c) {
	return
		explore(board, r, c, +1,  0) ||
		explore(board, r, c, -1,  0) ||
		explore(board, r, c,  0, +1) ||
		explore(board, r, c,  0, -1) ||
		explore(board, r, c, -1, -1) ||
		explore(board, r, c, -1, +1) ||
		explore(board, r, c, +1, -1) ||
		explore(board, r, c, +1, +1);
}

/* Nitty-gritty detail of looking for a set of straight-line
 * items all the same colour. Need to be very careful not to step
 * over the edge of the array
 */
int
explore(c4_t board, int r_fix, int c_fix, int r_off, int c_off) {
	int r_lim, c_lim;
	int r, c, i;
	r_lim = r_fix + (STRAIGHT-1)*r_off;
	c_lim = c_fix + (STRAIGHT-1)*c_off;
	/* can we go in the specified direction?
	 */
	if (r_lim<0 || r_lim>=HEIGHT || c_lim<0 || c_lim>=WIDTH) {
		/* no, not enough space */
		return 0;
	}
	/* can, so check the colours for all the same */
	for (i=1; i<STRAIGHT; i++) {
		r = r_fix + i*r_off;
		c = c_fix + i*c_off;
		if (board[r][c] != board[r_fix][c_fix]) {
			/* found one different, so cannotbe a row */
			return 0;
		}
	}
	/* by now, a straight row all the same colour has been found */
	return 1;
}

/* Try to find a good move for the specified colour
 */
int
suggest_move(c4_t board, char colour) {
	int c;
	/* look for a winning move for colour */
	for (c=0; c<WIDTH; c++) {
		/* temporarily move in column c... */
		if (do_move(board, c+1, colour)) {
			/* ... and check to see the outcome */
			if (winner_found(board) == colour) {
				/* it is good, so unassign and return c */
				undo_move(board, c+1);
				return c+1;
			} else {
				undo_move(board, c+1);
			}
		}
	}
	/* ok, no winning move, look for a blocking move */
	if (colour == RED) {
		colour = YELLOW;
	} else {
		colour = RED;
	}
	for (c=0; c<WIDTH; c++) {
		/* temporarily move in column c... */
		if (do_move(board, c+1, colour)) {
			/* ... and check to see the outcome */
			if (winner_found(board) == colour) {
				/* it is good, so unassign and return c */
				undo_move(board, c+1);
				return c+1;
			} else {
				undo_move(board, c+1);
			}
		}
	}
	/* no moves found? then pick at random... */
	c = rand()%WIDTH;
	while (board[HEIGHT-1][c]!=EMPTY) {
		c = rand()%WIDTH;
	}
	return c+1;
}

