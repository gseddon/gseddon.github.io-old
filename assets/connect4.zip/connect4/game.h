#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <netdb.h> 
#include <signal.h>
#include <pthread.h>
	/* number of columns in the game */
#define WIDTH		7
	/* number of slots in each column */
#define HEIGHT		6
	/* number in row required for victory */
#define STRAIGHT	4
	/* sign that a cell is still empty */
#define EMPTY		'-'
	/* the two colours used in the game */
#define RED		'R'
#define YELLOW		'Y'
	/* horizontal size of each cell in the display grid */
#define WGRID	5
	/* vertical size of each cell in the display grid */
#define HGRID	3

#define RSEED	876545678

#define ANSI_RED     "\x1b[31m"
#define ANSI_YELLOW  "\x1b[33m"
#define ANSI_RESET   "\x1b[0m"

#define BUFSIZE 1024
#define GAMEOVER "Game Over"
#define INVALIDMOVE "Invalid Move"
#define ACK "ACK"

typedef char c4_t[HEIGHT][WIDTH];

struct thread_data{
   int 	sockfd;
   char	ip[40];
};


FILE* logfile;
pthread_mutex_t lock;


void* run_game(void* sockid);
void print_config(c4_t);
void init_empty(c4_t);
int do_move(c4_t, int, char);
void undo_move(c4_t, int);
int get_move(c4_t, int);
int move_possible(c4_t);
char winner_found(c4_t);
int rowformed(c4_t,  int r, int c);
int explore(c4_t, int r_fix, int c_fix, int r_off, int c_off);
int suggest_move(c4_t board, char colour);
void error(char *msg);
